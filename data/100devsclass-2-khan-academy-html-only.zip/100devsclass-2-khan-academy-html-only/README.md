# #100devs - Class 2 Khan Academy HTML only

A Pen created on CodePen.io. Original URL: [https://codepen.io/uhohfreakshow/pen/mdvYKRB](https://codepen.io/uhohfreakshow/pen/mdvYKRB).

